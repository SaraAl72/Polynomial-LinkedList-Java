// Sara Al-Hachami
// CIS 2353 (Data Structures)
// Project 2
//Summer 2025
// This program reads polynomials from a file and lets users add them together
//It also displays my capability of handling polynomials using linked lists and allowing for file input, storage, display, and addition.

import java.util.*;
import java.io.*;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        ArrayList<Polynomial> polyList = new ArrayList<>();

        // Try to read polynomial strings from file
        try {
            BufferedReader br = new BufferedReader(new FileReader("polynomial.txt"));
            String line;
            while ((line = br.readLine()) != null) {
                Polynomial p = new Polynomial(line); // Create polynomial from file line
                polyList.add(p); // Add to list
            } // end while loop (file reading)
            br.close();
        } catch (IOException e) {
            System.out.println("Error reading file.");
            return;
        }

        // Menu loop
        while (true) {
            System.out.println("\nList of Polynomials:");
            for (int i = 0; i < polyList.size(); i++) {
                System.out.print(i + ": ");
                polyList.get(i).print(); // Print each polynomial
            } // end printing for loop

            System.out.println("Which do you wish to add? Press -1 to Exit.");
            String userLine = input.nextLine().trim();

            if (userLine.equals("-1")) break; // Exit condition

            String[] nums = userLine.split(" ");
            if (nums.length != 2) {
                System.out.println("Invalid input.");
                continue;
            }

            try {
                int a = Integer.parseInt(nums[0]);
                int b = Integer.parseInt(nums[1]);

                // Check if the inputs are valid
                if (a < 0 || b < 0 || a >= polyList.size() || b >= polyList.size()) {
                    System.out.println("Invalid input.");
                    continue;
                }

                // Add selected polynomials
                Polynomial added = Polynomial.add(polyList.get(a), polyList.get(b));
                polyList.add(added); // adds the new polynomial to the end of the ArrayList

            } catch (NumberFormatException e) {
                System.out.println("Invalid input format.");
            }
        } // end the menu while loop

        input.close();
    } // end main
} // end class
