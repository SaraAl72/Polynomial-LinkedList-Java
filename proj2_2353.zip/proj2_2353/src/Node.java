//  Sara Al-Hachami
//  CIS 2353 (Data Structures)
//  Project 2
//Summer 2025
// This class represents one term in a polynomial

public class Node {
    int coefficient;     // given
    int exponent;        // The power of x, also given
    Node nextNode;       // Pointer to the next node, also given

    public Node(int coefficient, int exponent) {
        this.coefficient = coefficient;
        this.exponent = exponent;
        this.nextNode = null; // No next node yet
    } // end constructor
} // end class