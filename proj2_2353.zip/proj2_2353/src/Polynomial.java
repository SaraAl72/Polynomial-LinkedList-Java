// Sara Al-Hachami
// CIS 2353 (Data Structures)
//Summer 2025
// Project 2
// This class builds and stores a polynomial using a linked list

public class Polynomial {
    private Node head; // Points to the beginning of the polynomial

    // No-argument constructor
    public Polynomial() {
        this.head = null; // Starts empty
    } // end constructor

    // Constructs polynomial from a string
    public Polynomial(String line) {
        this.head = null;

        String[] parts = line.split("\\+"); // Break input string into terms

        for (String term : parts) {
            term = term.trim();
            int coef, exp;

            if (term.contains("x")) {
                String[] bits = term.split("x\\^?");
                coef = Integer.parseInt(bits[0]);
                exp = (bits.length == 2) ? Integer.parseInt(bits[1]) : 1;
            } else {
                coef = Integer.parseInt(term);
                exp = 0; // Constant term
            }

            insertSorted(new Node(coef, exp)); // Add new term
        } // end for loop
    } // end constructor

    // Adds a new term to the list in descending exponent order
    private void insertSorted(Node newNode) {
        if (head == null || newNode.exponent > head.exponent) {
            newNode.nextNode = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.nextNode != null && current.nextNode.exponent >= newNode.exponent) {
                current = current.nextNode;
            } // end while loop
            newNode.nextNode = current.nextNode;
            current.nextNode = newNode;
        }
    } // end insertSorted

    // Prints the polynomial like 4x^2+2x+3
    public void print() {
        Node current = head;
        StringBuilder result = new StringBuilder();

        while (current != null) {
            result.append(current.coefficient).append("x^").append(current.exponent);
            if (current.nextNode != null) {
                result.append("+");
            }
            current = current.nextNode;
        } // end the building string while loop.

        System.out.println(result);
    } // end print

    // Adds two polynomials and returns the sum as a new one
    public static Polynomial add(Polynomial p1, Polynomial p2) {
        Polynomial sum = new Polynomial(); // new result
        Node a = p1.head;
        Node b = p2.head;

        while (a != null || b != null) {
            if (b == null || (a != null && a.exponent > b.exponent)) {
                sum.insertSorted(new Node(a.coefficient, a.exponent));
                a = a.nextNode;
            } else if (a == null || b.exponent > a.exponent) {
                sum.insertSorted(new Node(b.coefficient, b.exponent));
                b = b.nextNode;
            } else {
                // Same exponent, add coefficients
                int combined = a.coefficient + b.coefficient;
                sum.insertSorted(new Node(combined, a.exponent));
                a = a.nextNode;
                b = b.nextNode;
            }
        } // end while loop

        return sum;
    } // end add
} // end class
